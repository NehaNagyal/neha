package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.EBillDaoImpl;
import com.cg.dao.IEBillDao;
import com.cg.dto.BillDTO;
import com.cg.dto.ConsumerDTO;
import com.cg.exception.BillException;

public class EBillServiceImpl implements IEBillService{
	IEBillDao dao;
	public EBillServiceImpl(){
		dao=new EBillDaoImpl();
	}
	
	@Override
public int insertBillDetails(BillDTO bill)throws BillException{
	return dao.insertBillDetails(bill);
	
}

@Override
public ConsumerDTO selectConsumerDetails(String conNo) throws BillException{
	return dao.selectConsumerDetails(conNo);
	
}

@Override
public ArrayList<BillDTO> selectBillDetails(String conNo) throws BillException {
	return dao.selectBillDetails(conNo);
}

@Override
public ArrayList<ConsumerDTO> listConsumers() throws BillException {
	return dao.listConsumers();
}

}
