package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDTO;
import com.cg.dto.ConsumerDTO;
import com.cg.exception.BillException;

public interface IEBillService {
	public int insertBillDetails(BillDTO bill) throws BillException;
	public ConsumerDTO selectConsumerDetails(String conNo) throws BillException;
	//public ConsumerDTO selectConsumerDetails(String conNo);
	public ArrayList<BillDTO> selectBillDetails(String conNo)throws BillException;
	public ArrayList<ConsumerDTO> listConsumers()throws BillException;

}
