package com.cg.servletdemo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.BillDTO;
import com.cg.dto.ConsumerDTO;
import com.cg.exception.BillException;
import com.cg.service.EBillServiceImpl;
import com.cg.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    IEBillService service;
   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        service=new EBillServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BillDTO bill=new BillDTO();
		String action=request.getParameter("action");
		RequestDispatcher rd;
		switch(action){
		case "1": 
			String conNo=request.getParameter("custnumber");
	        String lreading=request.getParameter("lastReading");
	        String creading=request.getParameter("currentReading");
	        double fixed=100;
	        double  units=Integer.parseInt(lreading)-Integer.parseInt(creading)+100;
	        double amount=units*1.15+fixed;
	        		bill.setConsumerNo(conNo);
	        		bill.setCurrentReading(Double.parseDouble(creading));
	        		bill.setUnitsConsumed(units);
	        		bill.setNetAmount(amount);
	        		PrintWriter out=response.getWriter();
	        		//out.println(bill);
	        		try{
	        			//out.println("hello");
	        			int billid=service.insertBillDetails(bill);
	        		//	out.println("hello");
	        			ConsumerDTO consumer=service.selectConsumerDetails(conNo);
	        			//out.println("hello");
	        			request.setAttribute("Bill",bill);
	        			request.setAttribute("consumer",consumer);
	        			 rd=request.getRequestDispatcher("PrintBill.jsp");
	        			rd.forward(request, response);
	        		}
	        		catch(BillException e){
	        			request.setAttribute("Error", e.getMessage());
	        			 rd=request.getRequestDispatcher("Error.jsp");
	        			rd.forward(request, response);
	        		}
	        		
	        		break;
	        		
		case "2":
			try{
				ArrayList<ConsumerDTO> list=service.listConsumers();
				request.setAttribute("consumerList", list);
				rd=request.getRequestDispatcher("Show_ConsumerList.jsp");
				rd.forward(request,response);
			}
			catch(BillException e){
    			request.setAttribute("Error", e.getMessage());
    			 rd=request.getRequestDispatcher("Error.jsp");
    			rd.forward(request, response);
    		}
    		break; 
    		
		case "3":
			rd=request.getRequestDispatcher("Search_Consumer.jsp");
			rd.forward(request,response);
			break;
			
		case "4":
			conNo= request.getParameter("conNo");
			try{
				ConsumerDTO consumer=service.selectConsumerDetails(conNo);
				request.setAttribute("consumer",consumer);
				//PrintWriter pw=response.getWriter();
				//pw.println(consumer);
				rd=request.getRequestDispatcher("Show_Consumer.jsp");
				rd.forward(request,response);
				break;
			}
			catch(BillException e){
    			request.setAttribute("Error", e.getMessage());
    			 rd=request.getRequestDispatcher("Error.jsp");
    			rd.forward(request, response);
    		}
    		break;
		
    		
		case "6":
			String cno= request.getParameter("consumerNo");
			try {
				ArrayList<BillDTO> list= service.selectBillDetails(cno);
				request.setAttribute("billList", list);
				rd=request.getRequestDispatcher("Show_Bills.jsp");
				rd.forward(request, response);
			} catch (BillException e) {
				request.setAttribute("Error", e.getMessage());
				rd= request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
			break;
			
		case "7" : 
				response.sendRedirect("Bill_Info.html");
				break;
		}
		
    		
    		
    		
    		
    		
			
		}}		
		
	


