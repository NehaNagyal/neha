package com.cg.dto;

import java.time.LocalDate;

public class BillDTO {

	private String billNo;
	private String consumerNo;
	private double currentReading;
	private double unitsConsumed;
	private double netAmount;
	private LocalDate billDate;
	public String getBillNo() {
		return billNo;
	}
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	public String getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	public double getCurrentReading() {
		return currentReading;
	}
	public void setCurrentReading(double currentReading) {
		this.currentReading = currentReading;
	}
	public double getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(double unitConsumed) {
		this.unitsConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
		//billDate.getMonth().name();
	}
	@Override
	public String toString() {
		return "BillDTO [billNo=" + billNo + ", consumerNo=" + consumerNo
				+ ", currentReading=" + currentReading + ", unitsConsumed="
				+ unitsConsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]";
	}
	
}
