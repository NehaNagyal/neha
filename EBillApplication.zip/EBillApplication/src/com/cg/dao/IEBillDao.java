package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.BillDTO;
import com.cg.dto.ConsumerDTO;
import com.cg.exception.BillException;

public interface IEBillDao {
	public int insertBillDetails(BillDTO bill)throws BillException;
	public ConsumerDTO selectConsumerDetails(String conNo)throws BillException;
	//public ArrayList<BillDTO> selectBillDetails(String conNo)throws BillException;
	public ArrayList<ConsumerDTO> listConsumers()throws BillException;
	ArrayList<BillDTO> selectBillDetails(String conNo) throws BillException;
}
