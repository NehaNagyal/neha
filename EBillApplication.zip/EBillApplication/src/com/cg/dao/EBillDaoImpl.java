package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




import java.util.ArrayList;



import com.cg.dto.BillDTO;
import com.cg.dto.ConsumerDTO;
import com.cg.exception.BillException;
import com.cg.utility.DBUtil;

public class EBillDaoImpl implements IEBillDao{
int billid=0;
	
	public int insertBillDetails(BillDTO bill)throws BillException{
		Connection con=DBUtil.createConnection();
		String sql="insert into billdetails(bill_num,consumer_num,cur_reading,unitConsumed,"
				+ "netAmount,bill_date) values(seq_bill_num.nextval,?,?,?,?,sysdate)";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(bill.getConsumerNo()));
			ps.setDouble(2, bill.getCurrentReading());
			ps.setDouble(3, bill.getUnitsConsumed());
			ps.setDouble(4, bill.getNetAmount());
			int r=ps.executeUpdate();
			if(r==1)
			{
				Statement s=con.createStatement();
				ResultSet rs= s.executeQuery("select seq_bill_num.currval from dual");
				if(rs.next())
				return rs.getInt(1);
				
			}
		} catch(SQLException e){
			if(e.getErrorCode()==2291)
				throw new BillException("Invalid Consumer Number");
			else
		        throw new BillException(e.getMessage());
	}
	
		return billid;
		
	}
	@Override
	public ConsumerDTO selectConsumerDetails(String conNo)throws BillException{
		ConsumerDTO consumer=new ConsumerDTO();
		Connection con=DBUtil.createConnection();
		String sql="select * from consumers where consumer_num=?";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(conNo));
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				consumer.setConsumerNo(rs.getString(1));
				consumer.setConsumerName(rs.getString(2));
				consumer.setAddress(rs.getString(3));
			}
		}catch(SQLException e){
			throw new BillException(e.getMessage());
			
			}
			return consumer;
		}
	@Override
	public ArrayList<BillDTO> selectBillDetails(String conNo)
			throws BillException {
		
		ArrayList<BillDTO> list= new ArrayList<>();
		String sql= "Select * from billDetails where consumer_num=?";
		try {
			Connection con= DBUtil.createConnection();
			PreparedStatement st= con.prepareStatement(sql);
			st.setString(1, conNo);
			ResultSet rs= st.executeQuery();
				while(rs.next()){
					
					BillDTO bill= new BillDTO();
						bill.setBillNo(rs.getString(1));
						bill.setConsumerNo(rs.getString(2));
						bill.setCurrentReading(rs.getDouble(3));
						bill.setUnitsConsumed(rs.getDouble(4));
						bill.setNetAmount(rs.getDouble(5));
						Date dt= rs.getDate(6);
						bill.setBillDate(dt.toLocalDate());
						list.add(bill);
				}
					
		} catch (SQLException e) {

			throw new BillException(e.getMessage());
		}
return list;
	}
		
		
		public ArrayList<ConsumerDTO> listConsumers()throws BillException{
			Connection connStudent=null;
			PreparedStatement pstStudent=null;
			
			ArrayList<ConsumerDTO> consumerList=new ArrayList<ConsumerDTO>();
			try{
			Connection con=DBUtil.createConnection();
			String sql="select * from consumers";
			
				PreparedStatement ps=con.prepareStatement(sql);
				
				ResultSet rset=ps.executeQuery();
				while(rset.next()){
					ConsumerDTO consumerDTO=new ConsumerDTO();
					consumerDTO.setConsumerNo(rset.getString(1));
					consumerDTO.setConsumerName(rset.getString(2));
					consumerDTO.setAddress(rset.getString(3));
					consumerList.add(consumerDTO);
					
					
				}
			}catch(SQLException e){
				throw new BillException(e.getMessage());
				
				}
				return consumerList;
			}
			 
		}
	

