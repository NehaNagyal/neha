package com.bill.presentation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bill.dao.EBillDAOImpl;
import com.bill.dao.IEBillDAO;
import com.bill.dto.BillDetailsDTO;
import com.bill.exception.EBillException;
import com.bill.service.EBillServiceImpl;
import com.bill.service.IEBillService;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/BillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BillDetailsDTO billDetailsDTO;
	IEBillService eBillServiceImpl;
	IEBillDAO eBillDAOImpl;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
        billDetailsDTO=new BillDetailsDTO();
        eBillServiceImpl=new EBillServiceImpl();
        eBillDAOImpl=new EBillDAOImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String consNumber=request.getParameter("consNumber");
		String lastReading=request.getParameter("lastReading");
		String currReading=request.getParameter("currReading");
		String user=request.getParameter("user");
		PrintWriter out=response.getWriter();
		
		try
		{
		if(consNumber.matches("^[1-9][0-9]{5}$")==false&&(lastReading.matches("^[0-9]{1,3}$")==false||
				lastReading.matches("^[0-9]{1,3}[.][0-9]{1,2}$")==false)&&
				(currReading.matches("^[0-9]{1,3}$")==false||
						currReading.matches("^[0-9]{1,3}[.][0-9]{1,2}$")==false))
			throw new EBillException("Please enter credentials in specified format");
		
		
		
		else
		{
		int consNumberInt=Integer.parseInt(consNumber);
		float currReadingFloat=Float.parseFloat(currReading);
		float lastReadingFloat=Float.parseFloat(lastReading);
		int check=0;
		int status=0;
		
		
		try {
			check=eBillDAOImpl.checkConsNumber(consNumberInt);
			
		} catch (EBillException e) {
			// TODO Auto-generated catch block
			out.println(e.getMessage());
		}
			
		if(check==0)
			out.println("Please enter valid consumer number");
		else
		{
			if(currReadingFloat>lastReadingFloat && 
					lastReadingFloat>0)
			{
				float units=currReadingFloat-lastReadingFloat;
				float netAmount=(float) (units*1.15+100);
				int billId;
				try {
					billId = eBillServiceImpl.getBillId();
				 	
				
					billDetailsDTO=new BillDetailsDTO(billId,consNumberInt,currReadingFloat
							,lastReadingFloat,units,netAmount);
					status=eBillServiceImpl.insertBillDetails(billDetailsDTO);
					
					//if(status!=0)
					//{
						out.println("<html><body>");
						out.println("<br>Hello: "+user);
						out.println("<br>Electricity Bill for consumer number: "+consNumberInt);
						out.println("<br><br>Unit Consumed: "+units);
						out.println("<br>Net Amount: "+netAmount);
						out.println("</body></html>");
						
					//}
					
				} catch (EBillException e) {
					// TODO Auto-generated catch block
					out.println(e.getMessage());
				}
				
			}
			else
			out.println("Please enter valid current month and last month meter details.");
		}
			
			
	}
		
	}catch(EBillException e)
		{
		out.println(e.getMessage());
	}

}
}
