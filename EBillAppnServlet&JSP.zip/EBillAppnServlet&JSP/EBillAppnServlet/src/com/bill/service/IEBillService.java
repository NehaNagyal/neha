package com.bill.service;

import com.bill.dto.BillDetailsDTO;
import com.bill.exception.EBillException;

public interface IEBillService 
{
	
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException;
	
	public int getBillId() throws EBillException;
	
}
