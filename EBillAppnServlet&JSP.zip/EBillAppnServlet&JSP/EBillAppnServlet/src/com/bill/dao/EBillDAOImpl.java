package com.bill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bill.dto.BillDetailsDTO;
import com.bill.exception.EBillException;
import com.bill.util.DBUtil;

public class EBillDAOImpl implements IEBillDAO {

	public EBillDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException {
		// TODO Auto-generated method stub
		int status=0;
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sql=new String("INSERT INTO billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount) "
				+ "VALUES(?,?,?,?,?)");
		try
		{
		connStudent=DBUtil.createConnection();
		
		pstStudent=connStudent.prepareStatement(sql);
		
		
		pstStudent.setInt(1,billDetailsDTO.getBillNo());
		pstStudent.setInt(2,billDetailsDTO.getConsumerNumber());
		pstStudent.setFloat(3,billDetailsDTO.getCurrReading());
		pstStudent.setFloat(4,billDetailsDTO.getUnits());
		pstStudent.setFloat(5,billDetailsDTO.getNetAmount());
		
		status=pstStudent.executeUpdate();
		
		
		
		}catch(SQLException se)
		{
			throw new EBillException("Record not inserted");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		return status;
	}

	@Override
	public int getBillId() throws EBillException {
		// TODO Auto-generated method stub
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int billId;
		
		String sql=new String("SELECT seq_bill_num.nextval FROM Dual");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		rset.next();
		billId=rset.getInt(1);
		
		}catch(SQLException se)
		{
			throw new EBillException("Problem in generating.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		
		
		return billId;
	}
	public int checkConsNumber(int consNumberInt) throws EBillException
	{
		int count=0;
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		try
		{
		connStudent=DBUtil.createConnection();
		
		String sql=new String("SELECT consumer_num FROM Consumers");
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		while(rset.next())
		{
			if(rset.getInt(1)==consNumberInt)
			{
				count=1;
				try
				{
					DBUtil.closeConnection();
				}catch(SQLException se)
				{
					throw new EBillException("Problems in closing connection.",se);
				}
				return count;
				
				
			}
			else continue;	
		}
		

		
		
		
		}
		catch(SQLException se)
		{
			throw new EBillException("No nobile with such mobile id is available.");
		}
		
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		return count;
	}

}
