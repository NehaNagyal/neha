package com.bill.dao;

import com.bill.dto.BillDetailsDTO;
import com.bill.exception.EBillException;

public interface IEBillDAO 
{
	
	public int checkConsNumber(int consNumberInt) throws EBillException;
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException;
	
	public int getBillId() throws EBillException;
	
}
