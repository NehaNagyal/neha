package com.bill.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {

	private static Connection conn;
	
	public static Connection createConnection() throws SQLException
	{
		
		try
		{
			InitialContext context = new InitialContext();
			DataSource ds =(DataSource) context.lookup("java:/jdbc/OracleDS");
			conn=ds.getConnection();
		}catch(NamingException e)
		{
			e.printStackTrace();
		}catch(SQLException e)
		{
			e.printStackTrace();;
		}
		return conn;
		
		
		
		/*ResourceBundle resOracle=ResourceBundle.getBundle("oracle2");
		String url=resOracle.getString("url");
		String username=resOracle.getString("username");
		String password=resOracle.getString("password");
		
		
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connStudent=DriverManager.getConnection(url,username,password);
		return connStudent;*/
	}
	
	public static void closeConnection() throws SQLException
	{
		if(conn!=null)
			conn.close();
	}
}
