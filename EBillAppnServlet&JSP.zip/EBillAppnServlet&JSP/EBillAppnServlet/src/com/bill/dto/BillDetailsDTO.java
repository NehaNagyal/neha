package com.bill.dto;

public class BillDetailsDTO
{
	int billNo;
	
	int consumerNumber;
	float currReading;
	float lastReading;
	float units;
	float netAmount;
	public float getUnits() {
		return units;
	}
	public void setUnits(float units) {
		this.units = units;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public float getLastReading() {
		return lastReading;
	}
	public void setLastReading(float lastReading) {
		this.lastReading = lastReading;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	public float getCurrReading() {
		return currReading;
	}
	public void setCurrReading(float currReading) {
		this.currReading = currReading;
	}
	public BillDetailsDTO() {
		super();
	}
	public BillDetailsDTO(int billNo, int consumerNumber, float currReading,
			float lastReading, float units, float netAmount) {
		super();
		this.billNo = billNo;
		this.consumerNumber = consumerNumber;
		this.currReading = currReading;
		this.lastReading = lastReading;
		this.units = units;
		this.netAmount = netAmount;
	}
	
	
	

}
