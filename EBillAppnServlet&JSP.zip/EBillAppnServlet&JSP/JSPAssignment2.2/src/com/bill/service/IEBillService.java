package com.bill.service;

import java.util.List;

import com.bill.dto.BillDetailsDTO;
import com.bill.dto.ConsumerDTO;
import com.bill.exception.EBillException;

public interface IEBillService 
{
	
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException;
	
	public int getBillId() throws EBillException;
	public ConsumerDTO selectConsumerDetails(String conNo) throws EBillException;
	public List<ConsumerDTO> selectConsumerDetails() throws EBillException;
	public List<BillDetailsDTO> selectBillDetails(String consumerNo) throws EBillException;
	
}
