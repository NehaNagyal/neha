import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.frs.dao.FlatRegisterationDAOImpl;
import com.cg.frs.dao.IFlatRegisterationDAO;
import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;


public class FlatRegisterationDAOImplTest {


	private IFlatRegisterationDAO flatDAO = new FlatRegisterationDAOImpl();
	@Test
	public void testRegisterFlat() throws FlatRegisterationException {
		
		FlatRegisterationDTO flat = new FlatRegisterationDTO();
		flat.setOwner_id(1);
		flat.setFlat_type(1);
		flat.setFlat_area(100);
		flat.setDeposit_amount(1000);
		flat.setRent_amount(2000);
		FlatRegisterationDTO flat1 = flatDAO.registerFlat(flat);
		assertEquals(1,flat1.getFlat_type());
	}

	@Test
	public void testValidateOwnerId() throws FlatRegisterationException {
		
		assertEquals(1,flatDAO.validateOwner(1));
		
	}

}
