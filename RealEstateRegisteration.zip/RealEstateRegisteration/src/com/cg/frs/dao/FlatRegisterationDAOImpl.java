package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.utility.DBUtil;


public class FlatRegisterationDAOImpl implements IFlatRegisterationDAO {
	
	private static Logger logger = Logger.getLogger(com.cg.frs.dao.FlatRegisterationDAOImpl.class);
	
	public FlatRegisterationDTO registerFlat(FlatRegisterationDTO flat)
			throws FlatRegisterationException {
		int status;
		String sql = new String("INSERT INTO flat_registration VALUES(flat_seq.nextVal,?,?,?,?,?)");
		String sql1 = new String("SELECT flat_seq.nextVal from dual");
		try{
			Connection con = DBUtil.createConnection();
				
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1,flat.getOwner_id());
			pst.setInt(2,flat.getFlat_type());
			pst.setInt(3,flat.getFlat_area());
			pst.setFloat(4,flat.getRent_amount());
			pst.setFloat(5,flat.getDeposit_amount());
			status = pst.executeUpdate();
			
			
	
			status = pst.executeUpdate();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql1);
			int flat_reg_no=0;
			while(rs.next()){
				flat_reg_no = rs.getInt(1);
			}
			flat.setFlat_reg_no(flat_reg_no);
			
			logger.info("Record inserted Successfully");

		}catch(SQLException se){
			logger.error(se.getMessage());
			throw new FlatRegisterationException("Record Not inserted",se);
		}finally{
			try{
				DBUtil.closeConnection();

			}catch(SQLException se){
				throw new FlatRegisterationException("Problem in SQL Connection",se);
			}
		}
		return flat;
	}
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegisterationException {
		// TODO Auto-generated method stub
		ArrayList<Integer> ownerIdList=new ArrayList<Integer>();
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		String sql=new String("SELECT owner_id FROM flat_owners");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		while(rset.next()){
			ownerIdList.add(rset.getInt(1));
		}
		logger.info("Owner Id displayed Successfully");
		
		}catch(SQLException se)
		{
			logger.error(se.getMessage());
			throw new  FlatRegisterationException("Problem in getting owner IDs.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new  FlatRegisterationException("Problems in closing connection.",se);
			}
		}
		
		
		return ownerIdList;
		
	}
	@Override
	public int validateOwner(int ownerId) throws FlatRegisterationException {
	
		int status=0;
		ArrayList<Integer> list = getAllOwnerIds();
		Iterator<Integer> it = list.iterator();
		while(it.hasNext())
		{
			int ownerId1 = it.next();
			if(ownerId==ownerId1){
				status=1;
			}	
		}
		
		if(status==1)
		{
			return 1;
		}
		else
			throw new FlatRegisterationException("Owner does not exists");
	}

	


}
