package com.cg.frs.dao;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;

public interface IFlatRegisterationDAO {

	public FlatRegisterationDTO registerFlat(FlatRegisterationDTO flat) throws FlatRegisterationException;
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegisterationException;
	int validateOwner(int ownerId) throws FlatRegisterationException;

}
