package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegisterationDAOImpl;
import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;

public class FlatRegistrationServiceImpl implements IFlatRegisterationService{

	FlatRegisterationDAOImpl flatDAO = new FlatRegisterationDAOImpl();
	@Override
	public FlatRegisterationDTO registerFlat(FlatRegisterationDTO flat)throws FlatRegisterationException {
		return flatDAO.registerFlat(flat);
	}
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegisterationException {
		
		return flatDAO.getAllOwnerIds();
	}
	@Override

	public int validateOwner(int ownerId) throws FlatRegisterationException {
		
		return flatDAO.validateOwner(ownerId);
	}

}
