package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;

public interface IFlatRegisterationService {

	public FlatRegisterationDTO registerFlat(FlatRegisterationDTO flat)throws FlatRegisterationException;
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegisterationException;
	public int validateOwner(int ownerId) throws FlatRegisterationException;



}



