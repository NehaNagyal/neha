    package com.cg.frs.ui;
	import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

	import com.cg.frs.dto.FlatRegisterationDTO;
import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;

	public class Client {

		@SuppressWarnings("resource")
		public static void main(String[] args) throws FlatRegisterationException {
			FlatRegistrationServiceImpl flatService = new FlatRegistrationServiceImpl();
			//IFlatRegisterationService flatService = new FlatRegistrationServiceImpl();
			FlatRegisterationDTO flat = new FlatRegisterationDTO();
			
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Please Enter the choice : \n1. Register Flat\n2. Exit");
			int choice = sc.nextInt();
			String ans="";
		
			switch(choice)
			{
			case 1: 

					ArrayList<Integer> ownerIds = flatService.getAllOwnerIds();
					Iterator<Integer> it = ownerIds.iterator();
					System.out.print("Existing Owner Ids are:-[");
					while(it.hasNext())
					{
						System.out.print(it.next()+" ");
					}
					System.out.print("]");
					Scanner sb = new Scanner(System.in);
					System.out.println("\nPlease enter your owner id from above list:");
					int ownerId = sb.nextInt();
					try {
						flatService.validateOwner(ownerId);
					} catch (FlatRegisterationException e) {
						System.err.println("OwnerId does not exists");
						break;
					}
					flat.setOwner_id(ownerId);
					
					System.out.println("Select Flat Type (1. 1BHK\n 2. 2BHK)");
					int flatType = sb.nextInt();
					//Validation of flat type
					if(flatType==1||flatType==2){
						
						flat.setFlat_type(flatType);
						System.out.println("Enter Flat area in sq. ft:");
						int flatArea = sb.nextInt();
						flat.setFlat_area(flatArea);
						System.out.println("Enter desired rent amount Rs:");
						float rentAmount = sb.nextFloat();
						System.out.println("Enter desired deposit amount Rs:");
						float depositAmount = sb.nextFloat();
						//Validation of Deposit and rent Amount
						if(depositAmount>0&&rentAmount>0&&depositAmount<rentAmount){
							System.err.println("Deposit Amount cannot be less than rent amount");
							break;
						}
						flat.setRent_amount(rentAmount);
						flat.setDeposit_amount(depositAmount);
						
						FlatRegisterationDTO flat1 = flatService.registerFlat(flat);
						System.out.println("Flat successfully registered. Registration id:<"+flat1.getFlat_reg_no()+">");
						
					}
					else
					{
						System.err.println("Please Enter valid Flat Type");
						break;
					}
			
					break;
			case 2: 
				System.out.println("Thanks for Registering in our Real Estate.");
				break;
			}
			
		}
			
		}

	
