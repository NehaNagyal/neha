/**
 * Creating a module Root scope works as 
 * global variable One for All Module
 */


 var myapp=angular.module('productDetail',[]).run(function($rootScope) {
	$rootScope.employeeId=1001;
	$rootScope.employeeName='Rahul Vikash';
});

 myapp.controller('ProductController', function($scope) {
	 $scope.product={
				'id': 1001,
				'name': 'Book',
				'price': 380
		};
 });