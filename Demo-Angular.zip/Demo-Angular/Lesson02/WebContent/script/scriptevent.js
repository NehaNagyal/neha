/**
 * On Any Events global counter value will increase 
 */

var eventNameSpace = angular.module('eventApp',[]);

eventNameSpace.controller('EventController',function($scope){
	$scope.counter = 0;
	$scope.status=false;
	$scope.statusText="Unchecked";
	
	$scope.IncrementCounter = function(){
		$scope.counter++;
	};
	
	$scope.ChangeCounter = function(flag){
		if(flag) 
			$scope.counter++;
		else
			$scope.counter--;
	};
	
	$scope.ChangeStatus = function(status){
		if(status)
			$scope.statusText="Checked";
		else
			$scope.statusText="Unchecked";
	};
});



